<?php $__env->startSection('container'); ?>
    <div class="mt-5">
        <h1>Beranda</h1>
    </div>

    <div class="row py-5 ">
        <div class="col-3">
            <div class="card m3" style="border-radius: 25px">
                <div class="card-body m-3 text-center">
                    <h3>Total Pesanan</h3>
                    <hr>
                    <h1>
                        <?php if(isset($totalPesanan)): ?>
                            <?php echo e($totalPesanan); ?>

                        <?php endif; ?>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card m3" style="border-radius: 25px">
                <div class="card-body m-3 text-center">
                    <h3>Pesanan Dibuat</h3>
                    <hr>
                    <h1>
                        <?php if(isset($totalDibuat)): ?>
                            <?php echo e($totalDibuat); ?>

                        <?php endif; ?>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-3 ">
            <div class="card m3" style="border-radius: 25px">
                <div class="card-body m-3 text-center">
                    <h3>Pesanan Diproses</h3>
                    <hr>
                    <h1>
                        <?php if(isset($totalDiproses)): ?>
                            <?php echo e($totalDiproses); ?>

                        <?php endif; ?>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card m3" style="border-radius: 25px">
                <div class="card-body m-3 text-center">
                    <h3>Pesanan Selesai</h3>
                    <hr>
                    <h1>
                        <?php if(isset($totalSelesai)): ?>
                            <?php echo e($totalSelesai); ?>

                        <?php endif; ?>
                    </h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DEV\ProjectLaravel\ErkaXpress\resources\views/adminHome.blade.php ENDPATH**/ ?>