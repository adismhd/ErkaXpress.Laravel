<?php $__env->startSection('container'); ?>

<div class="mt-5">
    <h1>Daftar Pesanan</h1>
</div>

<div class="table-responsive mt-5" >
    <table class="table">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">No Pesanan</th>
                <th scope="col">Nama Pemesan</th>
                <th scope="col">Nama Barang</th>
                <th scope="col">Berat Barang</th>
                <th scope="col">Status Saat Ini</th>
                <th scope="col">Tanggal Order</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pesananList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="" >
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->NoPesanan); ?></td>
                    <td><?php echo e($data->Pengirim->Nama); ?></td>
                    <td><?php echo e($data->Barang->Jenis); ?></td>
                    <td><?php echo e($data->Barang->Berat); ?> kg</td>
                    
                    <td>
                        <?php if($data->Status->last()->Status == 'Pesanan Dibuat'): ?>
                            <i class="fa-solid fa-circle-exclamation" style="color: red"></i>
                        <?php endif; ?> 
                        <?php if($data->Status->last()->Status == 'Pesanan Selesai Dikirim'): ?>
                            <i class="fa-solid fa-circle-check" style="color: rgb(62, 127, 62)"></i>
                        <?php endif; ?> 

                        <?php echo e($data->Status->last()->Status); ?>

                    </td>
                    <td><?php echo e($data->created_at); ?></td>
                    <td><a href="DetailPesanan/<?php echo e($data->NoPesanan); ?>" class="btn btn-sm btn-primary">Detail</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DEV\ProjectLaravel\ErkaXpress\resources\views/adminIndexPesanan.blade.php ENDPATH**/ ?>