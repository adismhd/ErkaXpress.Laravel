<?php $__env->startSection('container'); ?>

<style>
    p {
        color: black
    }
</style>
<hr >
<div class="row mt-3">
    <div class="container-fluid">
        <a href="/DetailPesanan/<?php echo e($pesanan->NoPesanan); ?>" class="btn btn-primary disabled">Detail</a> &nbsp;
        
        <a href="/MemoPesanan/<?php echo e($pesanan->NoPesanan); ?>" class="btn btn-primary">Memo</a> &nbsp;
    </div>
</div>
<hr >
<h1 class="mt-2">Detail Pesanan</h1>

<div class="card mt-3" style="border-radius: 25px">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <table>
                    <tbody>
                        <tr><td>Pesanan Dibuat Tanggal </td><td>&nbsp;:&nbsp;</td><td><?php echo e($pesanan->created_at); ?></td></tr>
                        <tr><td>Nomor Resi </td><td>&nbsp;:&nbsp;</td><td><?php echo e($pesanan->NoPesanan); ?></td></tr>
                        <tr><td>Pengirim </td><td>&nbsp;:&nbsp;</td><td><?php echo e($pengirim->Nama); ?></td></tr>
                        <tr><td>Status Sekarang </td><td>&nbsp;:&nbsp;</td><td><?php echo e($status->Status); ?></td></tr>
                        <tr><td>Email </td><td>&nbsp;:&nbsp;</td><td><?php echo e($pengirim->Email); ?></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
                <table class="" style="width: 100%">
                    <tbody>
                        <tr><td style="font-size: large">Total Harga </td><td>&nbsp;:&nbsp;</td><td  style="font-weight: bold; font-size: large">Rp. <?php echo e(formatRupiah($biaya->TotalBiaya)); ?></td></tr>
                        <tr><td>Asuransi </td><td>&nbsp;:&nbsp;</td>
                            <td>
                                <input type="checkbox" onclick="return false;" class="form-check"  <?php if($pesanan->Asuransi === '1'): ?> checked <?php endif; ?> />
                            </td>
                        </tr>
                        <tr><td>Packing </td><td>&nbsp;:&nbsp;</td>
                            <td>
                                <input type="checkbox" onclick="return false;" class="form-check"  <?php if($pesanan->Packing === '1'): ?> checked <?php endif; ?> />
                            </td>
                        </tr>
                        <tr><td></td><td></td>
                            <?php if($isCancle == true): ?>
                                <td style="text-align: right">
                                    <button type="button" class="btn btn-danger" onclick="showModalDeleteOrder()">Cancle Order</button>
                                </td>
                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card mt-3" style="border-radius: 25px">
    <div class="card-body">
        <table style="width: 100%">
            <tbody>
                <tr>
                    <td style="width: 15%">Status Pembayaran </td>
                    <td>&nbsp;:&nbsp;</td>
                    <td style="vertical-align: middle">
                        <?php if($biaya->Status == 'Menunggu Pembayaran'): ?>
                            
                            <i class="fa-solid fa-circle-exclamation" style="color: red"></i>
                            <?php echo e($biaya->Status); ?>

                        <?php else: ?>
                            <?php echo e($biaya->Status); ?>

                        <?php endif; ?> 
                        
                    </td>
                    <td style="text-align: right">
                        <a class="btn btn-primary" href="#" onclick="showModalBukti()">Bukti Pembayaran</a> &nbsp;
                        <a class="btn btn-primary" href="#" onclick="showModalStatus()">Ganti</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="card mt-3" style="border-radius: 25px; overflow: hidden;">
    <div class="card-header" style="overflow: hidden;">
        <h5>Pengiriman</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6 ">
                <div style="border-radius: 15px; ">
                    <table class="table table-sm table-info">
                        <thead  class="table-dark"><tr><th colspan="3">Pengirim</th></tr></thead>
                        <tbody>
                            <tr><td class="col-md-3">Nama </td><td>&nbsp;:&nbsp;</td><td><?php echo e($pengirim->Nama); ?></td></tr>
                            <tr><td>No. Telepon </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($pengirim->NoTelepon); ?></td></tr>
                            <?php if(isset($propinsiPengirim->Nama)): ?><tr><td>Propinsi </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($propinsiPengirim->Nama); ?></td></tr><?php endif; ?>
                            <tr><td>Alamat </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($pengirim->Alamat); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-6 ">
                <div style="border-radius: 15px;">
                    <table class="table table-sm table-success">
                        <thead class="table-dark"><tr><th colspan="3">Penerima</th></tr></thead>
                        <tbody>
                            <tr><td class="col-md-3">Nama </td><td>&nbsp;:&nbsp;</td><td><?php echo e($penerima->Nama); ?></td></tr>
                            <tr><td>No. Telepon </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($penerima->NoTelepon); ?></td></tr>
                            <tr><td>Propinsi </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($propinsiPenerima->Nama); ?></td></tr>
                            <tr><td>Alamat </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($penerima->Alamat); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="card mt-3" style="border-radius: 25px; overflow: hidden;">
    <div class="card-header" style="overflow: hidden;">
        <h5>Detail Barang</h5>
    </div>
    <div class="card-body">
        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-6 ">
                    <table class="">
                        <tbody>
                            <tr><td>Jenis Barang </td><td>&nbsp;:&nbsp;</td><td><?php echo e($item->Jenis); ?></td></tr>
                            <tr><td>Keterangan </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($item->Keterangan); ?></td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-6 ">
                    <table >
                        <tbody>
                            <tr><td>Jumlah Barang </td><td>&nbsp;:&nbsp;</td></td><td><?php echo e($item->Jumlah); ?></td></tr>
                            <tr><td>Harga Per Item </td><td>&nbsp;:&nbsp;</td></td><td>Rp. <?php echo e(formatRupiah($item->Harga)); ?></td></tr>
                            <tr><td>Total Harga  </td><td>&nbsp;:&nbsp;</td></td><td>Rp. <?php echo e(formatRupiah($item->Harga * $item->Jumlah)); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>



<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="InsertStatus" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" value="<?php echo e($pesanan->NoPesanan); ?>" name="NoPesanan" hidden />
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <label>Status <i style="color: crimson">*</i></label>
                        <select id="inLayanan" class="form-control mt-1" name="Status" required>
                            <option value=""  disabled selected hidden>-- Pilih --</option>    
                            <?php $__currentLoopData = $paramStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Code); ?>"><?php echo e($item->Nama); ?></option>                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12 mt-3">
                        <label>Keterangan <i style="color: crimson">*</i></label> 
                        <textarea id="inKeterangan" name="Keterangan" class="form-control mt-1"required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>            
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="modalEdit">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="EditStatus" method="post">
                <?php echo csrf_field(); ?>
                <input id="idStatus" type="text" name="Id" hidden />
                <input type="text" value="<?php echo e($pesanan->NoPesanan); ?>" name="NoPesanan" hidden />
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <label>Status <i style="color: crimson">*</i></label>
                        <select id="inEditStatus" class="form-control mt-1" name="Status" required>
                            <option value=""  disabled selected hidden>-- Pilih --</option>    
                            <?php $__currentLoopData = $paramStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Code); ?>"><?php echo e($item->Nama); ?></option>                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12 mt-3">
                        <label>Keterangan <i style="color: crimson">*</i></label> 
                        <textarea id="inEditKeterangan" name="Keterangan" class="form-control mt-1"required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>            
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="modalDelete">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="DeleteStatus" method="post">
                <?php echo csrf_field(); ?>
                <input id="idStatusDelete" type="text" name="Id" hidden />
                <input type="text" value="<?php echo e($pesanan->NoPesanan); ?>" name="NoPesanan" hidden />
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class="modal-title">Apakah anda yakin akan menghapus data?</h5>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Ya</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                </div>
            </form>            
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="myModalStatusPembayaran">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="EditStatusPembayaran" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" value="<?php echo e($pesanan->NoPesanan); ?>" name="NoPesanan" hidden />
                <div class="modal-header">
                    <h5 class="modal-title">Status Pembayaran</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <label>Status <i style="color: crimson">*</i></label>
                        <select id="inLayanan" class="form-control mt-1" name="Status" required>
                            <option value="Menunggu Pembayaran">Menunggu Pembayaran</option>    
                            <option value="Lunas" >Lunas</option>    
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>            
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="modalBukti">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <?php if($dokumenPembayaran == "null"): ?>
                    <label>Tidak ada bukti pembayaran</label>
                <?php else: ?>
                    <img src="<?php echo e(base64_decode($dokumenPembayaran)); ?>" class="img-fluid"> 
                <?php endif; ?>
            </div>         
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="myModalDeleteData">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <h4 style="text-align: center">APAKAH ANDA YAKIN AKAN MENGHAPUS DATA <?php echo e($pesanan->NoPesanan); ?> ?</h4>
            </div>
            <div class="modal-footer">
                <a href="/DeletePesananVendor/<?php echo e($pesanan->NoPesanan); ?>" class="btn btn-danger">Ya</a>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>           
        </div>
    </div>
</div>

<script type="text/javascript">
    function showModalTambah(){
        $('#myModal').modal({
            show: true,
            backdrop: 'static'
        });
    }

    function showModalEdit(id,status,keterangan){
        $('#idStatus').val(id);
        $('#inEditStatus').val(status);
        $('#inEditKeterangan').val(keterangan);
        $('#modalEdit').modal({
            show: true,
            backdrop: 'static'
        });
    }
    
    function showModalDelete(id){
        $('#idStatusDelete').val(id);
        $('#modalDelete').modal({
            show: true,
            backdrop: 'static'
        });
    }
    
    function showModalStatus(){
        $('#myModalStatusPembayaran').modal({
            show: true,
            backdrop: 'static'
        });
    }
    
    function showModalBukti(){
        $('#modalBukti').modal({
            show: true,
            backdrop: 'static'
        });
        console.log($("#dok").val());
    }

    function showModalDeleteOrder(){
        $('#myModalDeleteData').modal({
            show: true,
            backdrop: 'static'
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Project Kevin\Erkaxpress\ErkaXpress.Laravel\resources\views/adminView/vendorDetailPesanan.blade.php ENDPATH**/ ?>