<?php $__env->startSection('container'); ?>
<div class="mt-4">
    <h1>Daftar Pesanan</h1>
</div>

<div class="card mt-3" style="border-radius: 25px">    
    <div class="card-body" >
        <div class="table-responsive" style="border-radius: 15px;">
            <table class="table table-striped" style="">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">No Pesanan</th>
                        <th scope="col">Nama Pemesan</th>
                        <th scope="col">Nama Barang</th>
                        <th scope="col">Berat Barang</th>
                        <th scope="col">Status Saat Ini</th>
                        <th scope="col">Tanggal Order</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pesananList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="" >
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($data->NoPesanan); ?></td>
                            <td><?php echo e($data->Penerima->Nama); ?></td>
                            <td><?php echo e($data->Barang->Jenis); ?></td>
                            <td><?php echo e($data->Barang->Berat); ?> kg</td>
                            
                            <td>
                                <?php if($data->Status->last()->Status == 'Pesanan Dibuat'): ?>
                                    <i class="fa-solid fa-circle-exclamation" style="color: red"></i>
                                <?php endif; ?> 
                                <?php if($data->Status->last()->Status == 'Pesanan Selesai Dikirim'): ?>
                                    <i class="fa-solid fa-circle-check" style="color: rgb(62, 127, 62)"></i>
                                <?php endif; ?> 
    
                                <?php echo e($data->Status->last()->Status); ?>

                            </td>
                            <td><?php echo e($data->created_at); ?></td>
                            <td><a href="DetailPesananVendor/<?php echo e($data->NoPesanan); ?>" class="btn btn-sm btn-primary">Detail</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Project Kevin\Erkaxpress\ErkaXpress.Laravel\resources\views/adminView/vendorIndexPesanan.blade.php ENDPATH**/ ?>